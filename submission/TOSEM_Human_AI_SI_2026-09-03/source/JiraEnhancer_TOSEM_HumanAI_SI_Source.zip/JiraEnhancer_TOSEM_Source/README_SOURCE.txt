Jira Enhancer TOSEM main-manuscript source archive

Main file:
  jiraenhancer_tosem_acm.tex

Build command:
  latexmk -pdf -interaction=nonstopmode -halt-on-error jiraenhancer_tosem_acm.tex

The archive contains the main TeX file, its bibliography, and only the
figures and table fragments required to compile the main manuscript.
It does not contain a supplementary manuscript, raw study records,
reviewer materials, credentials, logs, caches, or Git history.

The build requires a TeX installation with the ACM acmart class,
ACM-Reference-Format bibliography style, and the packages imported by
the main file.
